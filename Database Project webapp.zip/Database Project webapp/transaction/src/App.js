import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import LoginPageMobile from "./pages/LoginPageMobile";
import NewHandAfterHandInputPageMob from "./pages/NewHandAfterHandInputPageMob";
import NewSessionPageMobile from "./pages/NewSessionPageMobile";
import NavBar from "./pages/NavBar";
import HomePageMobile from "./pages/HomePageMobile";
import NewSessionPageMobile1 from "./pages/NewSessionPageMobile1";
import AddHandPageMobile from "./pages/AddHandPageMobile";
import AllHandsPageMobile from "./pages/AllHandsPageMobile";
import AllHandsPageSelectedHandMob from "./pages/AllHandsPageSelectedHandMob";
import DraftsHandPageafterSelection from "./pages/DraftsHandPageafterSelection";
import NewHandPageMobile from "./pages/NewHandPageMobile";
import NewHandAfterHandInputPageMob1 from "./pages/NewHandAfterHandInputPageMob1";
import NewHandAfterHandInputPageMob2 from "./pages/NewHandAfterHandInputPageMob2";
import { useEffect } from "react";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/newhandafterhandinputpagemobile1":
        title = "";
        metaDescription = "";
        break;
      case "/newsessionpagemobile1":
        title = "";
        metaDescription = "";
        break;
      case "/navbar":
        title = "";
        metaDescription = "";
        break;
      case "/homepagemobile":
        title = "";
        metaDescription = "";
        break;
      case "/newsessionpagemobile":
        title = "";
        metaDescription = "";
        break;
      case "/addhandpagemobile":
        title = "";
        metaDescription = "";
        break;
      case "/allhandspagemobile":
        title = "";
        metaDescription = "";
        break;
      case "/allhandspageselected-handmobile":
        title = "";
        metaDescription = "";
        break;
      case "/draftshandpageafter-selectionmobile":
        title = "";
        metaDescription = "";
        break;
      case "/newhandpagemobile":
        title = "";
        metaDescription = "";
        break;
      case "/newhandafterhandinputpagemobilecorrect":
        title = "";
        metaDescription = "";
        break;
      case "/newhandafterhandinputpagemobile":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<LoginPageMobile />} />
      <Route
        path="/newhandafterhandinputpagemobile1"
        element={<NewHandAfterHandInputPageMob />}
      />
      <Route path="/newsessionpagemobile1" element={<NewSessionPageMobile />} />
      <Route path="/navbar" element={<NavBar />} />
      <Route path="/homepagemobile" element={<HomePageMobile />} />
      <Route path="/newsessionpagemobile" element={<NewSessionPageMobile1 />} />
      <Route path="/addhandpagemobile" element={<AddHandPageMobile />} />
      <Route path="/allhandspagemobile" element={<AllHandsPageMobile />} />
      <Route
        path="/allhandspageselected-handmobile"
        element={<AllHandsPageSelectedHandMob />}
      />
      <Route
        path="/draftshandpageafter-selectionmobile"
        element={<DraftsHandPageafterSelection />}
      />
      <Route path="/newhandpagemobile" element={<NewHandPageMobile />} />
      <Route
        path="/newhandafterhandinputpagemobilecorrect"
        element={<NewHandAfterHandInputPageMob1 />}
      />
      <Route
        path="/newhandafterhandinputpagemobile"
        element={<NewHandAfterHandInputPageMob2 />}
      />
    </Routes>
  );
}
export default App;
