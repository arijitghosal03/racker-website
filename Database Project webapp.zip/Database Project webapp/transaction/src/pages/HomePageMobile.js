import { useState, useCallback, useEffect } from "react";
import Header from "../components/Header";
import SessionsContainer from "../components/SessionsContainer";
import LeftDrawer from "../components/LeftDrawer";
import PortalDrawer from "../components/PortalDrawer";
import RightDrawer from "../components/RightDrawer";

const HomePageMobile = () => {
  const [isLeftDrawerOpen, setLeftDrawerOpen] = useState(false);
  const [isRightDrawerOpen, setRightDrawerOpen] = useState(false);
  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add("animate");
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  const openLeftDrawer = useCallback(() => {
    setLeftDrawerOpen(true);
  }, []);

  const closeLeftDrawer = useCallback(() => {
    setLeftDrawerOpen(false);
  }, []);

  const openRightDrawer = useCallback(() => {
    setRightDrawerOpen(true);
  }, []);

  const closeRightDrawer = useCallback(() => {
    setRightDrawerOpen(false);
  }, []);

  return (
    <>
      <div
        style={{
          position: "relative",
          backgroundColor: "#fff",
          width: "100%",
          height: "932px",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-start",
          justifyContent: "flex-start",
        }}
      >
        <Header dimensions="/onlylogo21.svg" />
        <div
          style={{
            flex: "1",
            display: "flex",
            flexDirection: "row",
            alignItems: "flex-start",
            justifyContent: "flex-start",
            position: "relative",
          }}
        >
          <SessionsContainer />
          <div
            style={{
              margin: "0",
              position: "absolute",
              top: "70px",
              left: "0px",
              height: "862px",
              display: "flex",
              flexDirection: "column",
              padding: "30px 0px",
              boxSizing: "border-box",
              alignItems: "flex-start",
              justifyContent: "flex-start",
              zIndex: "1",
            }}
          >
            <button
              style={{
                cursor: "pointer",
                border: "none",
                padding: "0",
                backgroundColor: "transparent",
                position: "relative",
                width: "40px",
                height: "20px",
                opacity: "0",
              }}
              onClick={openLeftDrawer}
              data-animate-on-scroll
            >
              <div
                style={{
                  position: "absolute",
                  height: "100%",
                  width: "100%",
                  top: "0%",
                  right: "0%",
                  bottom: "0%",
                  left: "0%",
                  borderRadius: "0px 3.33px 3.33px 0px",
                  backgroundColor: "#ececec",
                }}
              />
              <img
                style={{
                  position: "absolute",
                  height: "80%",
                  width: "40%",
                  top: "10%",
                  right: "30%",
                  bottom: "10%",
                  left: "30%",
                  maxWidth: "100%",
                  overflow: "hidden",
                  maxHeight: "100%",
                }}
                alt=""
                src="/connection--24--outline3.svg"
              />
            </button>
          </div>
          <div
            style={{
              margin: "0",
              position: "absolute",
              top: "70px",
              left: "397px",
              height: "862px",
              display: "flex",
              flexDirection: "column",
              padding: "30px 0px",
              boxSizing: "border-box",
              alignItems: "flex-end",
              justifyContent: "flex-start",
              zIndex: "2",
            }}
          >
            <button
              style={{
                cursor: "pointer",
                border: "none",
                padding: "0",
                backgroundColor: "transparent",
                width: "32px",
                height: "15px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                opacity: "0",
              }}
              onClick={openRightDrawer}
              data-animate-on-scroll
            >
              <img
                style={{ position: "relative", width: "40px", height: "20px" }}
                alt=""
                src="/rectangle-1.svg"
              />
              <img
                style={{
                  position: "relative",
                  width: "16px",
                  height: "16px",
                  overflow: "hidden",
                  flexShrink: "0",
                  marginTop: "-27px",
                }}
                alt=""
                src="/connection--24--outline11.svg"
              />
            </button>
          </div>
        </div>
      </div>
      {isLeftDrawerOpen && (
        <PortalDrawer
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Left"
          onOutsideClick={closeLeftDrawer}
        >
          <LeftDrawer onClose={closeLeftDrawer} />
        </PortalDrawer>
      )}
      {isRightDrawerOpen && (
        <PortalDrawer
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Right"
          onOutsideClick={closeRightDrawer}
        >
          <RightDrawer onClose={closeRightDrawer} />
        </PortalDrawer>
      )}
    </>
  );
};

export default HomePageMobile;
