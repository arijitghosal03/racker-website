import { useState, useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import MainHeader from "../components/MainHeader";
import LeftDrawer from "../components/LeftDrawer";
import PortalDrawer from "../components/PortalDrawer";
import BottomFooter from "../components/BottomFooter";
import RightDrawer from "../components/RightDrawer";

const AddHandPageMobile = () => {
  const navigate = useNavigate();
  const [isLeftDrawerOpen, setLeftDrawerOpen] = useState(false);
  const [isRightDrawerOpen, setRightDrawerOpen] = useState(false);

  const onButtonSecondaryWithIconLeClick = useCallback(() => {
    navigate("/newhandpagemobile");
  }, [navigate]);

  const onButtonSecondaryWithIconLe1Click = useCallback(() => {
    navigate("/allhandspagemobile");
  }, [navigate]);

  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add("animate");
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  const openLeftDrawer = useCallback(() => {
    setLeftDrawerOpen(true);
  }, []);

  const closeLeftDrawer = useCallback(() => {
    setLeftDrawerOpen(false);
  }, []);

  const openRightDrawer = useCallback(() => {
    setRightDrawerOpen(true);
  }, []);

  const closeRightDrawer = useCallback(() => {
    setRightDrawerOpen(false);
  }, []);

  return (
    <>
      <div
        style={{
          position: "relative",
          backgroundColor: "#fff",
          width: "100%",
          height: "932px",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-start",
          justifyContent: "flex-start",
          textAlign: "center",
          fontSize: "12.93px",
          color: "#1d2129",
          fontFamily: "Vollkorn",
        }}
      >
        <MainHeader dimensions="/onlylogo4.svg" />
        <div
          style={{
            alignSelf: "stretch",
            flex: "1",
            overflow: "hidden",
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: "10px",
          }}
        >
          <div
            style={{
              alignSelf: "stretch",
              display: "flex",
              flexDirection: "column",
              padding: "75px 0px",
              alignItems: "flex-start",
              justifyContent: "flex-start",
            }}
          >
            <button
              style={{
                cursor: "pointer",
                border: "none",
                padding: "0",
                backgroundColor: "transparent",
                position: "relative",
                width: "40px",
                height: "20px",
                opacity: "0",
              }}
              onClick={openLeftDrawer}
              data-animate-on-scroll
            >
              <div
                style={{
                  position: "absolute",
                  height: "100%",
                  width: "100%",
                  top: "0%",
                  right: "0%",
                  bottom: "0%",
                  left: "0%",
                  borderRadius: "0px 3.92px 3.92px 0px",
                  backgroundColor: "#ececec",
                }}
              />
              <img
                style={{
                  position: "absolute",
                  height: "80%",
                  width: "40%",
                  top: "10%",
                  right: "30%",
                  bottom: "10%",
                  left: "30%",
                  maxWidth: "100%",
                  overflow: "hidden",
                  maxHeight: "100%",
                }}
                alt=""
                src="/connection--24--outline4.svg"
              />
            </button>
          </div>
          <div
            style={{
              alignSelf: "stretch",
              flex: "1",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "flex-end",
              position: "relative",
              gap: "200px",
            }}
          >
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "flex-start",
                gap: "46.16px",
                zIndex: "0",
              }}
            >
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "flex-start",
                  gap: "14.77px",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "flex-start",
                    gap: "11.08px",
                    fontSize: "18.47px",
                  }}
                >
                  <img
                    style={{
                      position: "relative",
                      width: "22.16px",
                      height: "22.16px",
                      overflow: "hidden",
                      flexShrink: "0",
                    }}
                    alt=""
                    src="/icon.svg"
                  />
                  <div
                    style={{
                      position: "relative",
                      lineHeight: "20.31px",
                      fontWeight: "500",
                    }}
                  >
                    Rules
                  </div>
                </div>
                <div
                  style={{
                    borderRadius: "1.85px",
                    backgroundColor: "#f7f7f8",
                    display: "flex",
                    flexDirection: "row",
                    padding: "11.079108238220215px 9.232590675354004px",
                    alignItems: "flex-start",
                    justifyContent: "flex-start",
                  }}
                >
                  <div
                    style={{
                      position: "relative",
                      lineHeight: "18.47px",
                      display: "inline-block",
                      width: "194.24px",
                      flexShrink: "0",
                    }}
                  >
                    <p style={{ margin: "0" }}>May occasionally generate</p>
                    <p style={{ margin: "0" }}>incorrect information</p>
                  </div>
                </div>
                <div
                  style={{
                    borderRadius: "1.85px",
                    backgroundColor: "#f7f7f8",
                    display: "flex",
                    flexDirection: "row",
                    padding: "11.079108238220215px 9.232590675354004px",
                    alignItems: "flex-start",
                    justifyContent: "flex-start",
                  }}
                >
                  <div
                    style={{
                      position: "relative",
                      lineHeight: "18.47px",
                      display: "inline-block",
                      width: "194.24px",
                      flexShrink: "0",
                    }}
                  >
                    May occasionally produce harmful instructions or biased
                    content
                  </div>
                </div>
                <div
                  style={{
                    borderRadius: "1.85px",
                    backgroundColor: "#f7f7f8",
                    display: "flex",
                    flexDirection: "row",
                    padding: "11.079108238220215px 9.232590675354004px",
                    alignItems: "flex-start",
                    justifyContent: "flex-start",
                  }}
                >
                  <div
                    style={{
                      position: "relative",
                      lineHeight: "18.47px",
                      display: "inline-block",
                      width: "194.24px",
                      flexShrink: "0",
                    }}
                  >
                    Limited knowledge of world and events after 2021
                  </div>
                </div>
              </div>
              <div
                style={{
                  overflow: "hidden",
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "flex-start",
                  justifyContent: "flex-start",
                  gap: "17.97px",
                }}
              >
                <div
                  style={{
                    position: "relative",
                    borderRadius: "50%",
                    backgroundColor: "#acacac",
                    width: "12px",
                    height: "11.96px",
                  }}
                />
                <div
                  style={{
                    position: "relative",
                    borderRadius: "50%",
                    backgroundColor: "#e9e9e9",
                    width: "12px",
                    height: "11.96px",
                  }}
                />
                <div
                  style={{
                    position: "relative",
                    borderRadius: "50%",
                    backgroundColor: "#e9e9e9",
                    width: "12px",
                    height: "11.96px",
                  }}
                />
              </div>
            </div>
            <BottomFooter
              dimensions="/plus--24--outline.svg"
              dimensions1="/justify-alignment--24--outline1.svg"
              dimensions2="/minus--24--outline1.svg"
              dimensions3="/paper-plane--24--outline1.svg"
              propZIndex="1"
              propCursor="pointer"
              propCursor1="pointer"
              onButtonSecondaryWithIconLeClick={
                onButtonSecondaryWithIconLeClick
              }
              onButtonSecondaryWithIconLe1Click={
                onButtonSecondaryWithIconLe1Click
              }
            />
            <div
              style={{
                margin: "0",
                position: "absolute",
                top: "39px",
                left: "16px",
                overflow: "hidden",
                display: "flex",
                flexDirection: "row",
                padding: "1.6823214292526245px 0px",
                alignItems: "center",
                justifyContent: "flex-start",
                gap: "8.41px",
                zIndex: "2",
                textAlign: "left",
                fontSize: "11.78px",
                color: "#000",
              }}
            >
              <img
                style={{
                  position: "relative",
                  width: "16.82px",
                  height: "13.46px",
                }}
                alt=""
                src="/vector4.svg"
              />
              <div
                style={{
                  position: "relative",
                  lineHeight: "16.82px",
                  fontWeight: "500",
                }}
              >
                Edit Session
              </div>
            </div>
          </div>
          <div
            style={{
              alignSelf: "stretch",
              display: "flex",
              flexDirection: "column",
              padding: "75px 0px",
              alignItems: "flex-end",
              justifyContent: "flex-start",
            }}
          >
            <button
              style={{
                cursor: "pointer",
                border: "none",
                padding: "0",
                backgroundColor: "transparent",
                position: "relative",
                width: "40px",
                height: "20px",
                opacity: "0",
              }}
              onClick={openRightDrawer}
              data-animate-on-scroll
            >
              <div
                style={{
                  position: "absolute",
                  height: "100%",
                  width: "100%",
                  top: "0%",
                  right: "0%",
                  bottom: "0%",
                  left: "0%",
                  borderRadius: "5px 0px 0px 5px",
                  backgroundColor: "#ececec",
                }}
              />
              <img
                style={{
                  position: "absolute",
                  height: "80%",
                  width: "40%",
                  top: "10%",
                  right: "30%",
                  bottom: "10%",
                  left: "30%",
                  maxWidth: "100%",
                  overflow: "hidden",
                  maxHeight: "100%",
                }}
                alt=""
                src="/connection--24--outline5.svg"
              />
            </button>
          </div>
        </div>
      </div>
      {isLeftDrawerOpen && (
        <PortalDrawer
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Left"
          onOutsideClick={closeLeftDrawer}
        >
          <LeftDrawer onClose={closeLeftDrawer} />
        </PortalDrawer>
      )}
      {isRightDrawerOpen && (
        <PortalDrawer
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Right"
          onOutsideClick={closeRightDrawer}
        >
          <RightDrawer onClose={closeRightDrawer} />
        </PortalDrawer>
      )}
    </>
  );
};

export default AddHandPageMobile;
