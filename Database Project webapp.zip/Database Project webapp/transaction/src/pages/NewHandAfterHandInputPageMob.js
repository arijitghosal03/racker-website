import { useCallback, useEffect } from "react";
import MainHeader from "../components/MainHeader";
import AIResponseForm from "../components/AIResponseForm";
import { useNavigate } from "react-router-dom";
import BottomFooter from "../components/BottomFooter";

const NewHandAfterHandInputPageMob = () => {
  const navigate = useNavigate();
  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add("animate");
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  const onButtonSecondaryWithIconLeClick = useCallback(() => {
    navigate("/newhandafterhandinputpagemobile");
  }, [navigate]);

  return (
    <div
      style={{
        position: "relative",
        backgroundColor: "#fff",
        width: "100%",
        height: "932px",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        justifyContent: "flex-start",
        textAlign: "left",
        fontSize: "13.68px",
        color: "#0d1a26",
        fontFamily: "Vollkorn",
      }}
    >
      <MainHeader dimensions="/onlylogo1.svg" />
      <div
        style={{
          alignSelf: "stretch",
          flex: "1",
          overflow: "hidden",
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          gap: "10px",
        }}
      >
        <div
          style={{
            alignSelf: "stretch",
            display: "flex",
            flexDirection: "column",
            padding: "75px 0px",
            alignItems: "flex-start",
            justifyContent: "flex-start",
          }}
        >
          <button
            style={{
              cursor: "pointer",
              border: "none",
              padding: "0",
              backgroundColor: "transparent",
              position: "relative",
              width: "40px",
              height: "20px",
              opacity: "0",
            }}
            data-animate-on-scroll
          >
            <div
              style={{
                position: "absolute",
                height: "100%",
                width: "100%",
                top: "0%",
                right: "0%",
                bottom: "0%",
                left: "0%",
                borderRadius: "0px 3.92px 3.92px 0px",
                backgroundColor: "#ececec",
              }}
            />
            <img
              style={{
                position: "absolute",
                height: "80%",
                width: "40%",
                top: "10%",
                right: "30%",
                bottom: "10%",
                left: "30%",
                maxWidth: "100%",
                overflow: "hidden",
                maxHeight: "100%",
              }}
              alt=""
              src="/connection--24--outline.svg"
            />
          </button>
        </div>
        <div
          style={{
            alignSelf: "stretch",
            flex: "1",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "flex-end",
            position: "relative",
            gap: "30px",
          }}
        >
          <AIResponseForm
            dimensions="/round-only-logo.svg"
            dimensionsText="/approvetick--24--outline.svg"
            dimensions1557="/history2.svg"
            sessionNameInputTop="14.63px"
            propCursor="unset"
          />
          <div
            style={{
              alignSelf: "stretch",
              borderRadius: "12.82px",
              backgroundColor: "#f2f2f2",
              boxShadow: "0px 0px 6.84px rgba(0, 0, 0, 0.25)",
              display: "flex",
              flexDirection: "column",
              padding:
                "17.09682846069336px 13.677462577819824px 13.677462577819824px 15px",
              alignItems: "flex-start",
              justifyContent: "flex-start",
              position: "relative",
              gap: "25px",
              zIndex: "1",
            }}
          >
            <img
              style={{
                position: "absolute",
                margin: "0",
                top: "13.68px",
                left: "13.68px",
                width: "42.74px",
                height: "42.74px",
                zIndex: "0",
              }}
              alt=""
              src="/round-only-logo1.svg"
            />
            <div
              style={{
                alignSelf: "stretch",
                display: "flex",
                flexDirection: "column",
                padding: "0px 0px 0px 50px",
                alignItems: "flex-start",
                justifyContent: "flex-start",
                gap: "17px",
                zIndex: "1",
              }}
            >
              <div
                style={{
                  alignSelf: "stretch",
                  position: "relative",
                  letterSpacing: "0.01em",
                  lineHeight: "20.52px",
                  fontWeight: "600",
                }}
              >
                Is this summary of the above hand correct?
              </div>
              <div
                style={{
                  alignSelf: "stretch",
                  position: "relative",
                  letterSpacing: "0.01em",
                  lineHeight: "20.52px",
                }}
              >
                <p style={{ margin: "0" }}>
                  sjdf isjrfn sifjisd sijflsj sddifj
                </p>
                <p
                  style={{ margin: "0" }}
                >{`ssjkdnfk iuerjf sdofu sdjg adfgjdifagh adfuga `}</p>
                <p style={{ margin: "0" }}>dfihgksj suhgks suhfs rus sfgj</p>
              </div>
            </div>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "flex-start",
                gap: "20px",
                zIndex: "2",
                fontSize: "10.53px",
                color: "#252a31",
              }}
            >
              <div
                style={{
                  borderRadius: "2.26px",
                  backgroundColor: "#e8edf1",
                  boxShadow:
                    "0px 1.5038560628890991px 3.01px rgba(0, 0, 0, 0.25)",
                  height: "33.08px",
                  display: "flex",
                  flexDirection: "row",
                  padding: "7.519280433654785px 0px",
                  boxSizing: "border-box",
                  alignItems: "flex-start",
                  justifyContent: "flex-start",
                  gap: "6.02px",
                  cursor: "pointer",
                }}
                onClick={onButtonSecondaryWithIconLeClick}
              >
                <div
                  style={{ position: "relative", width: "4px", height: "24px" }}
                />
                <img
                  style={{
                    position: "relative",
                    width: "18.05px",
                    height: "18.05px",
                    overflow: "hidden",
                    flexShrink: "0",
                  }}
                  alt=""
                  src="/approvetick--24--outline1.svg"
                />
                <div
                  style={{
                    position: "relative",
                    lineHeight: "15.04px",
                    fontWeight: "500",
                  }}
                >
                  Correct
                </div>
                <div
                  style={{ position: "relative", width: "8px", height: "24px" }}
                />
              </div>
              <div
                style={{
                  borderRadius: "2.26px",
                  backgroundColor: "#e8edf1",
                  boxShadow:
                    "0px 1.5038560628890991px 3.01px rgba(0, 0, 0, 0.25)",
                  height: "33.08px",
                  display: "flex",
                  flexDirection: "row",
                  padding: "7.519280433654785px 0px",
                  boxSizing: "border-box",
                  alignItems: "flex-start",
                  justifyContent: "flex-start",
                  gap: "6.02px",
                }}
              >
                <div
                  style={{ position: "relative", width: "4px", height: "24px" }}
                />
                <img
                  style={{
                    position: "relative",
                    width: "15.04px",
                    height: "15.04px",
                    overflow: "hidden",
                    flexShrink: "0",
                  }}
                  alt=""
                  src="/pencil--24--outline.svg"
                />
                <div
                  style={{
                    position: "relative",
                    lineHeight: "15.04px",
                    fontWeight: "500",
                  }}
                >
                  Edit
                </div>
                <div
                  style={{ position: "relative", width: "8px", height: "24px" }}
                />
              </div>
              <div
                style={{
                  borderRadius: "2.26px",
                  backgroundColor: "#e8edf1",
                  boxShadow:
                    "0px 1.5038560628890991px 3.01px rgba(0, 0, 0, 0.25)",
                  height: "33.08px",
                  display: "flex",
                  flexDirection: "row",
                  padding: "7.519280433654785px 0px",
                  boxSizing: "border-box",
                  alignItems: "flex-start",
                  justifyContent: "flex-start",
                  gap: "6.02px",
                }}
              >
                <div
                  style={{ position: "relative", width: "4px", height: "24px" }}
                />
                <img
                  style={{
                    position: "relative",
                    width: "15.57px",
                    height: "15.57px",
                    overflow: "hidden",
                    flexShrink: "0",
                  }}
                  alt=""
                  src="/history3.svg"
                />
                <div
                  style={{
                    position: "relative",
                    lineHeight: "15.04px",
                    fontWeight: "500",
                  }}
                >
                  Save to Drafts
                </div>
                <div
                  style={{ position: "relative", width: "8px", height: "24px" }}
                />
              </div>
            </div>
          </div>
          <BottomFooter
            dimensions="/plus--24--outline2.svg"
            dimensions1="/justify-alignment--24--outline.svg"
            dimensions2="/minus--24--outline.svg"
            dimensions3="/paper-plane--24--outline.svg"
            propZIndex="2"
            propCursor="pointer"
            propCursor1="pointer"
          />
          <div
            style={{
              margin: "0",
              position: "absolute",
              top: "39px",
              left: "16px",
              overflow: "hidden",
              display: "flex",
              flexDirection: "row",
              padding: "1.6823214292526245px 0px",
              alignItems: "center",
              justifyContent: "flex-start",
              gap: "8.41px",
              zIndex: "3",
              fontSize: "11.78px",
              color: "#000",
            }}
          >
            <img
              style={{
                position: "relative",
                width: "16.82px",
                height: "13.46px",
              }}
              alt=""
              src="/vector3.svg"
            />
            <div
              style={{
                position: "relative",
                lineHeight: "16.82px",
                fontWeight: "500",
              }}
            >
              Edit Session
            </div>
          </div>
        </div>
        <div
          style={{
            alignSelf: "stretch",
            display: "flex",
            flexDirection: "column",
            padding: "75px 0px",
            alignItems: "flex-end",
            justifyContent: "flex-start",
          }}
        >
          <button
            style={{
              cursor: "pointer",
              border: "none",
              padding: "0",
              backgroundColor: "transparent",
              position: "relative",
              width: "40px",
              height: "20px",
              opacity: "0",
            }}
            data-animate-on-scroll
          >
            <div
              style={{
                position: "absolute",
                height: "100%",
                width: "100%",
                top: "0%",
                right: "0%",
                bottom: "0%",
                left: "0%",
                borderRadius: "5px 0px 0px 5px",
                backgroundColor: "#ececec",
              }}
            />
            <img
              style={{
                position: "absolute",
                height: "80%",
                width: "40%",
                top: "10%",
                right: "30%",
                bottom: "10%",
                left: "30%",
                maxWidth: "100%",
                overflow: "hidden",
                maxHeight: "100%",
              }}
              alt=""
              src="/connection--24--outline1.svg"
            />
          </button>
        </div>
      </div>
    </div>
  );
};

export default NewHandAfterHandInputPageMob;
