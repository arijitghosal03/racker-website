import { useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Form } from "react-bootstrap";
import MainHeader from "../components/MainHeader";
import AIResponseForm from "../components/AIResponseForm";
import AIResponseContainer from "../components/AIResponseContainer";

const NewHandAfterHandInputPageMob2 = () => {
  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add("animate");
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  return (
    <div
      style={{
        position: "relative",
        backgroundColor: "#fff",
        width: "100%",
        height: "932px",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        justifyContent: "flex-start",
        textAlign: "left",
        fontSize: "14px",
        color: "#0d1a26",
        fontFamily: "Vollkorn",
      }}
    >
      <MainHeader dimensions="/onlylogo8.svg" />
      <div
        style={{
          alignSelf: "stretch",
          flex: "1",
          overflow: "hidden",
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          gap: "10px",
        }}
      >
        <div
          style={{
            alignSelf: "stretch",
            display: "flex",
            flexDirection: "column",
            padding: "75px 0px",
            alignItems: "flex-start",
            justifyContent: "flex-start",
          }}
        >
          <button
            style={{
              cursor: "pointer",
              border: "none",
              padding: "0",
              backgroundColor: "transparent",
              position: "relative",
              width: "40px",
              height: "20px",
              opacity: "0",
            }}
            data-animate-on-scroll
          >
            <div
              style={{
                position: "absolute",
                height: "100%",
                width: "100%",
                top: "0%",
                right: "0%",
                bottom: "0%",
                left: "0%",
                borderRadius: "0px 3.92px 3.92px 0px",
                backgroundColor: "#ececec",
              }}
            />
            <img
              style={{
                position: "absolute",
                height: "80%",
                width: "40%",
                top: "10%",
                right: "30%",
                bottom: "10%",
                left: "30%",
                maxWidth: "100%",
                overflow: "hidden",
                maxHeight: "100%",
              }}
              alt=""
              src="/connection--24--outline6.svg"
            />
          </button>
        </div>
        <div
          style={{
            alignSelf: "stretch",
            flex: "1",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "flex-end",
            position: "relative",
            gap: "20px",
          }}
        >
          <AIResponseForm
            dimensions="/round-only-logo7.svg"
            dimensionsText="/approvetick--24--outline5.svg"
            dimensions1557="/history6.svg"
          />
          <AIResponseContainer
            dimensionsText="/round-only-logo8.svg"
            dimensionsCode="/approvetick--24--outline6.svg"
            dimensions15Text="/pencil--24--outline2.svg"
            dimensions1557Text="/history7.svg"
          />
          <div
            style={{
              alignSelf: "stretch",
              borderRadius: "13.46px",
              backgroundColor: "#f2f2f2",
              boxShadow: "0px 0px 7.18px rgba(0, 0, 0, 0.25)",
              display: "flex",
              flexDirection: "column",
              padding:
                "17.94019889831543px 14.35215950012207px 14.35215950012207px 71.76079559326172px",
              alignItems: "flex-start",
              justifyContent: "flex-start",
              position: "relative",
              gap: "17.94px",
              zIndex: "2",
            }}
          >
            <img
              style={{
                position: "absolute",
                margin: "0",
                top: "8.07px",
                left: "14.35px",
                width: "37.67px",
                height: "37.67px",
                zIndex: "0",
              }}
              alt=""
              src="/round-only-logo9.svg"
            />
            <div
              style={{
                alignSelf: "stretch",
                position: "relative",
                letterSpacing: "0.01em",
                lineHeight: "21.53px",
                zIndex: "1",
              }}
            >
              Your hand is saved. Open the hand to review it.
            </div>
          </div>
          <div
            style={{
              alignSelf: "stretch",
              borderRadius: "13.46px",
              backgroundColor: "#f2f2f2",
              boxShadow: "0px 0px 7.18px rgba(0, 0, 0, 0.25)",
              display: "flex",
              flexDirection: "column",
              padding:
                "17.94019889831543px 14.35215950012207px 14.35215950012207px 71.76079559326172px",
              alignItems: "flex-start",
              justifyContent: "flex-start",
              position: "relative",
              gap: "17.94px",
              zIndex: "3",
            }}
          >
            <img
              style={{
                position: "absolute",
                margin: "0",
                top: "8.07px",
                left: "14.35px",
                width: "37.67px",
                height: "37.67px",
                zIndex: "0",
              }}
              alt=""
              src="/round-only-logo10.svg"
            />
            <div
              style={{
                alignSelf: "stretch",
                position: "relative",
                letterSpacing: "0.01em",
                lineHeight: "21.53px",
                zIndex: "1",
              }}
            >
              How much is your stack after game?
            </div>
          </div>
          <div
            style={{
              alignSelf: "stretch",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "flex-start",
              gap: "20px",
              zIndex: "4",
              fontSize: "9.94px",
              color: "#252a31",
            }}
          >
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "flex-start",
                justifyContent: "flex-start",
                gap: "18.74px",
              }}
            >
              <div
                style={{
                  borderRadius: "2.13px",
                  backgroundColor: "#e8edf1",
                  boxShadow:
                    "0px 1.419798731803894px 2.84px rgba(0, 0, 0, 0.25)",
                  height: "31.24px",
                  display: "flex",
                  flexDirection: "row",
                  padding: "7.098992824554443px 0px",
                  boxSizing: "border-box",
                  alignItems: "flex-start",
                  justifyContent: "flex-start",
                  gap: "5.68px",
                }}
              >
                <div
                  style={{ position: "relative", width: "4px", height: "24px" }}
                />
                <img
                  style={{
                    position: "relative",
                    width: "17.04px",
                    height: "17.04px",
                    overflow: "hidden",
                    flexShrink: "0",
                  }}
                  alt=""
                  src="/plus--24--outline1.svg"
                />
                <div
                  style={{
                    position: "relative",
                    lineHeight: "14.2px",
                    fontWeight: "500",
                  }}
                >
                  New Hand
                </div>
                <div
                  style={{ position: "relative", width: "8px", height: "24px" }}
                />
              </div>
              <div
                style={{
                  borderRadius: "2.13px",
                  backgroundColor: "#e8edf1",
                  boxShadow:
                    "0px 1.419798731803894px 2.84px rgba(0, 0, 0, 0.25)",
                  height: "31.24px",
                  display: "flex",
                  flexDirection: "row",
                  padding: "7.098992824554443px 0px",
                  boxSizing: "border-box",
                  alignItems: "flex-start",
                  justifyContent: "flex-start",
                  gap: "5.68px",
                }}
              >
                <div
                  style={{ position: "relative", width: "4px", height: "24px" }}
                />
                <img
                  style={{
                    position: "relative",
                    width: "17.04px",
                    height: "17.04px",
                    overflow: "hidden",
                    flexShrink: "0",
                  }}
                  alt=""
                  src="/justify-alignment--24--outline5.svg"
                />
                <div
                  style={{
                    position: "relative",
                    lineHeight: "14.2px",
                    fontWeight: "500",
                  }}
                >
                  Saved hands
                </div>
                <div
                  style={{ position: "relative", width: "8px", height: "24px" }}
                />
              </div>
              <div
                style={{
                  borderRadius: "2.13px",
                  backgroundColor: "#e8edf1",
                  boxShadow:
                    "0px 1.419798731803894px 2.84px rgba(0, 0, 0, 0.25)",
                  height: "31.24px",
                  display: "flex",
                  flexDirection: "row",
                  padding: "7.098992824554443px 0px",
                  boxSizing: "border-box",
                  alignItems: "flex-start",
                  justifyContent: "flex-start",
                  gap: "5.68px",
                }}
              >
                <div
                  style={{ position: "relative", width: "4px", height: "24px" }}
                />
                <img
                  style={{
                    position: "relative",
                    width: "14.2px",
                    height: "14.2px",
                    overflow: "hidden",
                    flexShrink: "0",
                  }}
                  alt=""
                  src="/minus--24--outline4.svg"
                />
                <div
                  style={{
                    position: "relative",
                    lineHeight: "14.2px",
                    fontWeight: "500",
                  }}
                >
                  End Session
                </div>
                <div
                  style={{ position: "relative", width: "8px", height: "24px" }}
                />
              </div>
            </div>
            <Form.Group
              style={{
                border: "none",
                backgroundColor: "transparent",
                alignSelf: "stretch",
              }}
            >
              <Form.Label>Amount</Form.Label>
              <Form.Control type="number" placeholder="Enter amount" />
            </Form.Group>
          </div>
          <div
            style={{
              margin: "0",
              position: "absolute",
              top: "39px",
              left: "16px",
              overflow: "hidden",
              display: "flex",
              flexDirection: "row",
              padding: "1.6823214292526245px 0px",
              alignItems: "center",
              justifyContent: "flex-start",
              gap: "8.41px",
              zIndex: "5",
              fontSize: "11.78px",
              color: "#000",
            }}
          >
            <img
              style={{
                position: "relative",
                width: "16.82px",
                height: "13.46px",
              }}
              alt=""
              src="/vector4.svg"
            />
            <div
              style={{
                position: "relative",
                lineHeight: "16.82px",
                fontWeight: "500",
              }}
            >
              Edit Session
            </div>
          </div>
        </div>
        <div
          style={{
            alignSelf: "stretch",
            display: "flex",
            flexDirection: "column",
            padding: "75px 0px",
            alignItems: "flex-end",
            justifyContent: "flex-start",
          }}
        >
          <button
            style={{
              cursor: "pointer",
              border: "none",
              padding: "0",
              backgroundColor: "transparent",
              position: "relative",
              width: "40px",
              height: "20px",
              opacity: "0",
            }}
            data-animate-on-scroll
          >
            <div
              style={{
                position: "absolute",
                height: "100%",
                width: "100%",
                top: "0%",
                right: "0%",
                bottom: "0%",
                left: "0%",
                borderRadius: "5px 0px 0px 5px",
                backgroundColor: "#ececec",
              }}
            />
            <img
              style={{
                position: "absolute",
                height: "80%",
                width: "40%",
                top: "10%",
                right: "30%",
                bottom: "10%",
                left: "30%",
                maxWidth: "100%",
                overflow: "hidden",
                maxHeight: "100%",
              }}
              alt=""
              src="/connection--24--outline8.svg"
            />
          </button>
        </div>
      </div>
    </div>
  );
};

export default NewHandAfterHandInputPageMob2;
