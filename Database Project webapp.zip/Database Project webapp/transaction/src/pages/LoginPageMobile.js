import { useCallback } from "react";
import Header from "../components/Header";

const LoginPageMobile = () => {
  const onButtonPrimaryDefaultClick = useCallback(() => {
    window.open("/newsessionpagemobile");
  }, []);

  return (
    <div
      style={{
        position: "relative",
        backgroundColor: "#fff",
        width: "100%",
        height: "932px",
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        justifyContent: "flex-start",
        textAlign: "left",
        fontSize: "14px",
        color: "#252a31",
        fontFamily: "Vollkorn",
      }}
    >
      <Header dimensions="/onlylogo.svg" />
      <div
        style={{
          alignSelf: "stretch",
          flex: "1",
          display: "flex",
          flexDirection: "column",
          padding: "250px 75px",
          alignItems: "center",
          justifyContent: "center",
          gap: "10px",
        }}
      >
        <div
          style={{ alignSelf: "stretch", position: "relative", height: "56px" }}
        >
          <div
            style={{
              position: "absolute",
              top: "0px",
              left: "0px",
              lineHeight: "20px",
              fontWeight: "600",
            }}
          >
            Username
          </div>
          <input
            style={{
              border: "1px solid #e8edf1",
              backgroundColor: "#fff",
              position: "absolute",
              width: "100%",
              top: "24px",
              right: "0%",
              left: "0%",
              borderRadius: "3px",
              boxSizing: "border-box",
              height: "32px",
            }}
            type="text"
            placeholder="    username"
            maxLength
            minLength
            required
            autoFocus
          />
        </div>
        <div
          style={{ alignSelf: "stretch", position: "relative", height: "56px" }}
        >
          <div
            style={{
              position: "absolute",
              top: "0px",
              left: "0px",
              lineHeight: "20px",
              fontWeight: "600",
            }}
          >
            Password
          </div>
          <input
            style={{
              border: "1px solid #e8edf1",
              backgroundColor: "#fff",
              position: "absolute",
              width: "100%",
              top: "24px",
              right: "0%",
              left: "0%",
              borderRadius: "3px",
              boxSizing: "border-box",
              height: "32px",
            }}
            type="text"
            placeholder="    password"
            maxLength
            minLength
            required
            autoFocus
          />
        </div>

        <div
          style={{
            borderRadius: "3px",
            backgroundColor: "#9d9d9d",
            display: "flex",
            flexDirection: "column",
            padding: "8px 50px",
            alignItems: "center",
            justifyContent: "flex-start",
            cursor: "pointer",
            textAlign: "center",
            fontSize: "12px",
            color: "#fff",
          }}
          onClick={onButtonPrimaryDefaultClick}
        >
          <div
            style={{
              position: "relative",
              lineHeight: "16px",
              fontWeight: "500",
            }}
          >
            Login
          </div>
        </div>
        <div
          style={{
            borderRadius: "3px",
            height: "32px",
            display: "flex",
            flexDirection: "row",
            padding: "10px 0px",
            boxSizing: "border-box",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "11px",
            color: "#1e1e1e",
          }}
        >
          <div
            style={{ position: "relative", width: "12px", height: "16px" }}
          />
          <div style={{ position: "relative", lineHeight: "16px" }}>
            No credentials? Join the waitlist now to get access
          </div>
          <div style={{ position: "relative", width: "8px", height: "16px" }} />
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-start",
              justifyContent: "flex-start",
            }}
          >
            <img
              style={{ position: "relative", width: "16px", height: "10.01px" }}
              alt=""
              src="/vector1.svg"
            />
          </div>
          <div style={{ position: "relative", width: "8px", height: "16px" }} />
        </div>
      </div>
    </div>
  );
};

export default LoginPageMobile;
