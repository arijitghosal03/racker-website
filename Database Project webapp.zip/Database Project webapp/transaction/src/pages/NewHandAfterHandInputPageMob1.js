import { useEffect } from "react";
import MainHeader from "../components/MainHeader";
import AIResponseForm from "../components/AIResponseForm";
import AIResponseContainer from "../components/AIResponseContainer";
import BottomFooter from "../components/BottomFooter";

const NewHandAfterHandInputPageMob1 = () => {
  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add("animate");
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  return (
    <div
      style={{
        position: "relative",
        backgroundColor: "#fff",
        width: "100%",
        height: "932px",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        justifyContent: "flex-start",
        textAlign: "left",
        fontSize: "14px",
        color: "#0d1a26",
        fontFamily: "Vollkorn",
      }}
    >
      <MainHeader dimensions="/onlylogo8.svg" />
      <div
        style={{
          alignSelf: "stretch",
          flex: "1",
          overflow: "hidden",
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          gap: "10px",
        }}
      >
        <div
          style={{
            alignSelf: "stretch",
            display: "flex",
            flexDirection: "column",
            padding: "75px 0px",
            alignItems: "flex-start",
            justifyContent: "flex-start",
          }}
        >
          <button
            style={{
              cursor: "pointer",
              border: "none",
              padding: "0",
              backgroundColor: "transparent",
              position: "relative",
              width: "40px",
              height: "20px",
              opacity: "0",
            }}
            data-animate-on-scroll
          >
            <div
              style={{
                position: "absolute",
                height: "100%",
                width: "100%",
                top: "0%",
                right: "0%",
                bottom: "0%",
                left: "0%",
                borderRadius: "0px 3.92px 3.92px 0px",
                backgroundColor: "#ececec",
              }}
            />
            <img
              style={{
                position: "absolute",
                height: "80%",
                width: "40%",
                top: "10%",
                right: "30%",
                bottom: "10%",
                left: "30%",
                maxWidth: "100%",
                overflow: "hidden",
                maxHeight: "100%",
              }}
              alt=""
              src="/connection--24--outline6.svg"
            />
          </button>
        </div>
        <div
          style={{
            alignSelf: "stretch",
            flex: "1",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "flex-end",
            position: "relative",
            gap: "20px",
          }}
        >
          <AIResponseForm
            dimensions="/round-only-logo4.svg"
            dimensionsText="/approvetick--24--outline3.svg"
            dimensions1557="/history4.svg"
            sessionNameInputTop="14.63px"
            propCursor="unset"
          />
          <AIResponseContainer
            dimensionsText="/round-only-logo5.svg"
            dimensionsCode="/approvetick--24--outline4.svg"
            dimensions15Text="/pencil--24--outline1.svg"
            dimensions1557Text="/history5.svg"
          />
          <div
            style={{
              alignSelf: "stretch",
              borderRadius: "13.46px",
              backgroundColor: "#f2f2f2",
              boxShadow: "0px 0px 7.18px rgba(0, 0, 0, 0.25)",
              display: "flex",
              flexDirection: "column",
              padding:
                "17.94019889831543px 14.35215950012207px 14.35215950012207px 71.76079559326172px",
              alignItems: "flex-start",
              justifyContent: "flex-start",
              position: "relative",
              gap: "17.94px",
              zIndex: "2",
            }}
          >
            <img
              style={{
                position: "absolute",
                margin: "0",
                top: "8.07px",
                left: "14.35px",
                width: "37.67px",
                height: "37.67px",
                zIndex: "0",
              }}
              alt=""
              src="/round-only-logo6.svg"
            />
            <div
              style={{
                alignSelf: "stretch",
                position: "relative",
                letterSpacing: "0.01em",
                lineHeight: "21.53px",
                zIndex: "1",
              }}
            >
              Your hand is saved. Open the hand to review it.
            </div>
          </div>
          <BottomFooter
            dimensions="/plus--24--outline2.svg"
            dimensions1="/justify-alignment--24--outline4.svg"
            dimensions2="/minus--24--outline3.svg"
            dimensions3="/paper-plane--24--outline11.svg"
          />
          <div
            style={{
              margin: "0",
              position: "absolute",
              top: "39px",
              left: "16px",
              overflow: "hidden",
              display: "flex",
              flexDirection: "row",
              padding: "1.6823214292526245px 0px",
              alignItems: "center",
              justifyContent: "flex-start",
              gap: "8.41px",
              zIndex: "4",
              fontSize: "11.78px",
              color: "#000",
            }}
          >
            <img
              style={{
                position: "relative",
                width: "16.82px",
                height: "13.46px",
              }}
              alt=""
              src="/vector4.svg"
            />
            <div
              style={{
                position: "relative",
                lineHeight: "16.82px",
                fontWeight: "500",
              }}
            >
              Edit Session
            </div>
          </div>
        </div>
        <div
          style={{
            alignSelf: "stretch",
            display: "flex",
            flexDirection: "column",
            padding: "75px 0px",
            alignItems: "flex-end",
            justifyContent: "flex-start",
          }}
        >
          <button
            style={{
              cursor: "pointer",
              border: "none",
              padding: "0",
              backgroundColor: "transparent",
              position: "relative",
              width: "40px",
              height: "20px",
              opacity: "0",
            }}
            data-animate-on-scroll
          >
            <div
              style={{
                position: "absolute",
                height: "100%",
                width: "100%",
                top: "0%",
                right: "0%",
                bottom: "0%",
                left: "0%",
                borderRadius: "5px 0px 0px 5px",
                backgroundColor: "#ececec",
              }}
            />
            <img
              style={{
                position: "absolute",
                height: "80%",
                width: "40%",
                top: "10%",
                right: "30%",
                bottom: "10%",
                left: "30%",
                maxWidth: "100%",
                overflow: "hidden",
                maxHeight: "100%",
              }}
              alt=""
              src="/connection--24--outline7.svg"
            />
          </button>
        </div>
      </div>
    </div>
  );
};

export default NewHandAfterHandInputPageMob1;
