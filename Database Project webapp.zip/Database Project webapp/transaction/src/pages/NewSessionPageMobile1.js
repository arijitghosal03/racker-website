import { useState, useCallback, useEffect } from "react";
import MainHeader from "../components/MainHeader";
import LeftDrawer from "../components/LeftDrawer";
import PortalDrawer from "../components/PortalDrawer";
import SessionForm from "../components/SessionForm";
import RightDrawer from "../components/RightDrawer";

const NewSessionPageMobile1 = () => {
  const [isRightDrawerOpen, setRightDrawerOpen] = useState(false);
  const [isLeftDrawerOpen, setLeftDrawerOpen] = useState(false);
  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add("animate");
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  const openRightDrawer = useCallback(() => {
    setRightDrawerOpen(true);
  }, []);

  const closeRightDrawer = useCallback(() => {
    setRightDrawerOpen(false);
  }, []);

  const onButtonClick = useCallback(() => {
    window.open("/addhandpagemobile");
  }, []);

  const openLeftDrawer = useCallback(() => {
    setLeftDrawerOpen(true);
  }, []);

  const closeLeftDrawer = useCallback(() => {
    setLeftDrawerOpen(false);
  }, []);

  return (
    <>
      <div
        style={{
          position: "relative",
          backgroundColor: "#fff",
          width: "100%",
          height: "932px",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-start",
          justifyContent: "flex-start",
        }}
      >
        <MainHeader dimensions="/onlylogo3.svg" />
        <form
          style={{
            alignSelf: "stretch",
            flex: "1",
            overflow: "hidden",
            display: "flex",
            flexDirection: "row",
            padding: "70px 0px",
            alignItems: "center",
            justifyContent: "center",
            gap: "10px",
          }}
          method="post"
        >
          <div
            style={{
              alignSelf: "stretch",
              display: "flex",
              flexDirection: "column",
              padding: "30px 0px",
              alignItems: "flex-start",
              justifyContent: "flex-start",
            }}
          >
            <button
              style={{
                cursor: "pointer",
                border: "none",
                padding: "0",
                backgroundColor: "transparent",
                position: "relative",
                width: "60px",
                height: "30px",
                opacity: "0",
              }}
              onClick={openRightDrawer}
              data-animate-on-scroll
            >
              <div
                style={{
                  position: "absolute",
                  height: "100%",
                  width: "100%",
                  top: "0%",
                  right: "0%",
                  bottom: "0%",
                  left: "0%",
                  borderRadius: "0px 5px 5px 0px",
                  backgroundColor: "#ececec",
                }}
              />
              <img
                style={{
                  position: "absolute",
                  height: "80%",
                  width: "40%",
                  top: "10%",
                  right: "30%",
                  bottom: "10%",
                  left: "30%",
                  maxWidth: "100%",
                  overflow: "hidden",
                  maxHeight: "100%",
                }}
                alt=""
                src="/connection--24--outline21.svg"
              />
            </button>
          </div>
          <form
            style={{
              alignSelf: "stretch",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: "20px",
            }}
            method="post"
          >
            <h2
              style={{
                margin: "0",
                position: "relative",
                fontSize: "24px",
                fontWeight: "400",
                fontFamily: "Vollkorn",
                color: "#000",
                textAlign: "left",
              }}
            >
              New Session
            </h2>
            <SessionForm />
            <button
              style={{
                cursor: "pointer",
                border: "1px solid #dcdee0",
                padding: "6px 12px",
                backgroundColor: "transparent",
                borderRadius: "4px",
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
              }}
              id="NewSessionDoneButton"
              onClick={onButtonClick}
            >
              <label
                style={{
                  cursor: "pointer",
                  position: "relative",
                  fontSize: "16px",
                  lineHeight: "150%",
                  fontWeight: "700",
                  fontFamily: "Vollkorn",
                  color: "#0d1a26",
                  textAlign: "left",
                }}
                htmlFor="NewSessionDoneButton"
              >
                Done
              </label>
            </button>
          </form>
          <div
            style={{
              alignSelf: "stretch",
              width: "47px",
              display: "flex",
              flexDirection: "column",
              padding: "30px 0px",
              boxSizing: "border-box",
              alignItems: "flex-end",
              justifyContent: "flex-start",
            }}
          >
            <button
              style={{
                cursor: "pointer",
                border: "none",
                padding: "0",
                backgroundColor: "transparent",
                position: "relative",
                width: "60px",
                height: "30px",
                opacity: "0",
              }}
              onClick={openLeftDrawer}
              data-animate-on-scroll
            >
              <div
                style={{
                  position: "absolute",
                  height: "100%",
                  width: "100%",
                  top: "0%",
                  right: "0%",
                  bottom: "0%",
                  left: "0%",
                  borderRadius: "5px 0px 0px 5px",
                  backgroundColor: "#ececec",
                }}
              />
              <img
                style={{
                  position: "absolute",
                  height: "80%",
                  width: "40%",
                  top: "10%",
                  right: "30%",
                  bottom: "10%",
                  left: "30%",
                  maxWidth: "100%",
                  overflow: "hidden",
                  maxHeight: "100%",
                }}
                alt=""
                src="/connection--24--outline31.svg"
              />
            </button>
          </div>
        </form>
      </div>
      {isRightDrawerOpen && (
        <PortalDrawer
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Left"
          onOutsideClick={closeRightDrawer}
        >
          <LeftDrawer onClose={closeRightDrawer} />
        </PortalDrawer>
      )}
      {isLeftDrawerOpen && (
        <PortalDrawer
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Right"
          onOutsideClick={closeLeftDrawer}
        >
          <RightDrawer onClose={closeLeftDrawer} />
        </PortalDrawer>
      )}
    </>
  );
};

export default NewSessionPageMobile1;
