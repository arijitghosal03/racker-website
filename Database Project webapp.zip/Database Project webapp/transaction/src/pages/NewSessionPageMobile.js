import { useCallback, useEffect } from "react";
import {
  Autocomplete,
  TextField,
  FormControlLabel,
  Switch,
} from "@mui/material";

const NewSessionPageMobile = () => {
  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add("animate");
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  const onButtonContainerClick = useCallback(() => {
    window.open("/addhandpagemobile");
  }, []);

  return (
    <div
      style={{
        position: "relative",
        backgroundColor: "#fff",
        width: "100%",
        height: "932px",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        justifyContent: "flex-start",
      }}
    >
      <nav
        style={{
          alignSelf: "stretch",
          borderBottom: "0.5px solid rgba(0, 0, 0, 0.5)",
          boxSizing: "border-box",
          height: "70.5px",
          display: "flex",
          flexDirection: "row",
          padding: "14px 30px",
          alignItems: "flex-start",
          justifyContent: "center",
          textAlign: "left",
          fontSize: "21.69px",
          color: "#141414",
          fontFamily: "Volkhov",
        }}
      >
        <div
          style={{
            width: "134px",
            height: "39.51px",
            display: "flex",
            flexDirection: "row",
            alignItems: "flex-end",
            justifyContent: "flex-start",
            gap: "3.1px",
            opacity: "0",
          }}
          data-animate-on-scroll
        >
          <img
            style={{
              position: "relative",
              width: "50.75px",
              height: "39.49px",
            }}
            alt=""
            src="/onlylogo2.svg"
          />
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              alignItems: "flex-end",
              justifyContent: "center",
            }}
          >
            <div style={{ position: "relative" }}>Racker.</div>
          </div>
        </div>
        <div
          style={{
            flex: "1",
            display: "flex",
            flexDirection: "row",
            padding: "0px 10px",
            alignItems: "center",
            justifyContent: "flex-end",
          }}
        >
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              padding: "6px 2px",
              alignItems: "flex-end",
              justifyContent: "center",
            }}
          >
            <button
              style={{
                cursor: "pointer",
                border: "none",
                padding: "10px",
                backgroundColor: "transparent",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                opacity: "0",
              }}
              data-animate-on-scroll
            >
              <img
                style={{
                  position: "relative",
                  width: "20px",
                  height: "12px",
                  opacity: "1",
                }}
                alt=""
                src="/vector2.svg"
                data-animate-on-scroll
              />
            </button>
          </div>
        </div>
      </nav>
      <div
        style={{
          alignSelf: "stretch",
          flex: "1",
          overflow: "hidden",
          display: "flex",
          flexDirection: "row",
          padding: "70px 0px",
          alignItems: "center",
          justifyContent: "center",
          gap: "10px",
        }}
      >
        <div
          style={{
            alignSelf: "stretch",
            display: "flex",
            flexDirection: "column",
            padding: "30px 0px",
            alignItems: "flex-start",
            justifyContent: "flex-start",
          }}
        >
          <button
            style={{
              cursor: "pointer",
              border: "none",
              padding: "0",
              backgroundColor: "transparent",
              position: "relative",
              width: "60px",
              height: "30px",
              opacity: "0",
            }}
            data-animate-on-scroll
          >
            <div
              style={{
                position: "absolute",
                height: "100%",
                width: "100%",
                top: "0%",
                right: "0%",
                bottom: "0%",
                left: "0%",
                borderRadius: "0px 5px 5px 0px",
                backgroundColor: "#ececec",
              }}
            />
            <img
              style={{
                position: "absolute",
                height: "80%",
                width: "40%",
                top: "10%",
                right: "30%",
                bottom: "10%",
                left: "30%",
                maxWidth: "100%",
                overflow: "hidden",
                maxHeight: "100%",
              }}
              alt=""
              src="/connection--24--outline2.svg"
            />
          </button>
        </div>
        <form
          style={{
            alignSelf: "stretch",
            flex: "1",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: "20px",
          }}
          method="post"
        >
          <h2
            style={{
              margin: "0",
              position: "relative",
              fontSize: "24px",
              fontWeight: "400",
              fontFamily: "Vollkorn",
              color: "#000",
              textAlign: "left",
            }}
          >
            New Session
          </h2>
          <div
            style={{
              alignSelf: "stretch",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "flex-start",
              gap: "10px",
            }}
          >
            <h3
              style={{
                margin: "0",
                position: "relative",
                fontSize: "16px",
                lineHeight: "12.03px",
                fontWeight: "600",
                fontFamily: "Vollkorn",
                color: "#0d1a26",
                textAlign: "left",
              }}
            >
              Add Table Details
            </h3>
            <div
              style={{
                alignSelf: "stretch",
                display: "flex",
                flexDirection: "column",
                alignItems: "flex-start",
                justifyContent: "center",
                gap: "7.22px",
              }}
            >
              <label
                style={{
                  cursor: "default",
                  alignSelf: "stretch",
                  position: "relative",
                  fontSize: "11px",
                  lineHeight: "150%",
                  fontFamily: "Vollkorn",
                  color: "#304050",
                  textAlign: "left",
                }}
                htmlFor="SessionNameInput"
              >
                Session Name
              </label>
              <input
                style={{
                  border: "0.6px solid #dcdee0",
                  fontFamily: "Vollkorn",
                  fontSize: "11px",
                  backgroundColor: "transparent",
                  alignSelf: "stretch",
                  borderRadius: "2.41px",
                  display: "flex",
                  flexDirection: "column",
                  padding: "4.813793182373047px 9.627586364746094px",
                  alignItems: "center",
                  justifyContent: "center",
                }}
                type="text"
                placeholder="John’s Private Game"
                maxLength
                minLength
                required
                id="SessionNameInput"
              />
            </div>
            <div
              style={{
                alignSelf: "stretch",
                display: "flex",
                flexDirection: "row",
                alignItems: "flex-start",
                justifyContent: "flex-start",
                gap: "10px",
              }}
            >
              <div
                style={{
                  flex: "1",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "flex-start",
                  justifyContent: "center",
                  gap: "7.22px",
                }}
              >
                <label
                  style={{
                    cursor: "default",
                    alignSelf: "stretch",
                    position: "relative",
                    fontSize: "11px",
                    lineHeight: "150%",
                    fontFamily: "Vollkorn",
                    color: "#304050",
                    textAlign: "left",
                  }}
                  htmlFor="BlindsInputField"
                >
                  Game Type
                </label>
                <input
                  style={{
                    border: "0.6px solid #dcdee0",
                    fontFamily: "Vollkorn",
                    fontSize: "11px",
                    backgroundColor: "transparent",
                    alignSelf: "stretch",
                    borderRadius: "2.41px",
                    display: "flex",
                    flexDirection: "column",
                    padding: "4.813793182373047px 9.627586364746094px",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                  type="text"
                  placeholder="Texas NLH"
                  maxLength
                  minLength
                  readOnly
                  id="BlindsInput"
                />
              </div>
              <div
                style={{
                  flex: "1",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "flex-start",
                  justifyContent: "center",
                  gap: "7.22px",
                }}
              >
                <label
                  style={{
                    cursor: "default",
                    alignSelf: "stretch",
                    position: "relative",
                    fontSize: "11px",
                    lineHeight: "150%",
                    fontFamily: "Vollkorn",
                    color: "#304050",
                    textAlign: "left",
                  }}
                  htmlFor="BlindsInputField"
                >
                  Game Format
                </label>
                <Autocomplete
                  style={{ alignSelf: "stretch" }}
                  disablePortal
                  options={["Cash Game", "Tournament"]}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      name="BlindsInput"
                      color="primary"
                      label=""
                      variant="outlined"
                      placeholder="Game format"
                      helperText=""
                    />
                  )}
                  id="BlindsInput"
                  size="small"
                />
              </div>
            </div>
            <div
              style={{
                alignSelf: "stretch",
                display: "flex",
                flexDirection: "row",
                alignItems: "flex-start",
                justifyContent: "flex-start",
                gap: "10px",
              }}
            >
              <div
                style={{
                  flex: "1",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "flex-start",
                  justifyContent: "center",
                  gap: "7.22px",
                }}
              >
                <label
                  style={{
                    cursor: "default",
                    alignSelf: "stretch",
                    position: "relative",
                    fontSize: "11px",
                    lineHeight: "150%",
                    fontFamily: "Vollkorn",
                    color: "#304050",
                    textAlign: "left",
                  }}
                  htmlFor="BlindsInputField"
                >
                  Buyin
                </label>
                <input
                  style={{
                    border: "0.6px solid #dcdee0",
                    fontFamily: "Vollkorn",
                    fontSize: "11px",
                    backgroundColor: "transparent",
                    alignSelf: "stretch",
                    borderRadius: "2.41px",
                    display: "flex",
                    flexDirection: "column",
                    padding: "4.813793182373047px 9.627586364746094px",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                  type="number"
                  placeholder="10000"
                  maxLength
                  minLength
                  id="BlindsInput"
                />
              </div>
              <div
                style={{
                  flex: "1",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "flex-start",
                  justifyContent: "center",
                  gap: "7.22px",
                }}
              >
                <label
                  style={{
                    cursor: "default",
                    alignSelf: "stretch",
                    position: "relative",
                    fontSize: "11px",
                    lineHeight: "150%",
                    fontFamily: "Vollkorn",
                    color: "#304050",
                    textAlign: "left",
                  }}
                  htmlFor="BlindsInputField"
                >
                  Currency
                </label>
                <Autocomplete
                  style={{ alignSelf: "stretch" }}
                  disablePortal
                  options={["USD", "INR", "EUR"]}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      name="BlindsInput"
                      color="primary"
                      label="US Dollars"
                      variant="outlined"
                      placeholder="USD"
                      helperText=""
                    />
                  )}
                  id="BlindsInput"
                  size="small"
                />
              </div>
            </div>
            <div
              style={{
                alignSelf: "stretch",
                display: "flex",
                flexDirection: "row",
                alignItems: "flex-start",
                justifyContent: "flex-start",
                gap: "10px",
              }}
            >
              <div
                style={{
                  flex: "1",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "flex-start",
                  justifyContent: "center",
                  gap: "7.22px",
                }}
              >
                <label
                  style={{
                    cursor: "default",
                    alignSelf: "stretch",
                    position: "relative",
                    fontSize: "11px",
                    lineHeight: "150%",
                    fontFamily: "Vollkorn",
                    color: "#304050",
                    textAlign: "left",
                  }}
                  htmlFor="BlindsInputField"
                >
                  SB/BB
                </label>
                <input
                  style={{
                    border: "0.6px solid #dcdee0",
                    fontFamily: "Vollkorn",
                    fontSize: "11px",
                    backgroundColor: "transparent",
                    alignSelf: "stretch",
                    borderRadius: "2.41px",
                    display: "flex",
                    flexDirection: "column",
                    padding: "4.813793182373047px 9.627586364746094px",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                  type="text"
                  placeholder="25/50"
                  maxLength
                  minLength
                  id="BlindsInput"
                />
              </div>
              <div
                style={{
                  flex: "1",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "flex-start",
                  justifyContent: "center",
                  gap: "7.22px",
                }}
              >
                <label
                  style={{
                    cursor: "default",
                    alignSelf: "stretch",
                    position: "relative",
                    fontSize: "11px",
                    lineHeight: "150%",
                    fontFamily: "Vollkorn",
                    color: "#304050",
                    textAlign: "left",
                  }}
                  htmlFor="BlindsInputField"
                >
                  BB ante
                </label>
                <input
                  style={{
                    border: "0.6px solid #dcdee0",
                    fontFamily: "Vollkorn",
                    fontSize: "11px",
                    backgroundColor: "transparent",
                    alignSelf: "stretch",
                    borderRadius: "2.41px",
                    display: "flex",
                    flexDirection: "column",
                    padding: "4.813793182373047px 9.627586364746094px",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                  type="text"
                  placeholder="0"
                  maxLength
                  minLength
                  id="BlindsInput"
                />
              </div>
              <div
                style={{
                  flex: "1",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "flex-start",
                  justifyContent: "center",
                  gap: "7.22px",
                }}
              >
                <label
                  style={{
                    cursor: "default",
                    alignSelf: "stretch",
                    position: "relative",
                    fontSize: "11px",
                    lineHeight: "150%",
                    fontFamily: "Vollkorn",
                    color: "#304050",
                    textAlign: "left",
                  }}
                  htmlFor="BlindsInputField"
                >
                  Table ante
                </label>
                <input
                  style={{
                    border: "0.6px solid #dcdee0",
                    fontFamily: "Vollkorn",
                    fontSize: "11px",
                    backgroundColor: "transparent",
                    alignSelf: "stretch",
                    borderRadius: "2.41px",
                    display: "flex",
                    flexDirection: "column",
                    padding: "4.813793182373047px 9.627586364746094px",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                  type="number"
                  placeholder="0"
                  maxLength
                  minLength
                  id="BlindsInput"
                />
              </div>
            </div>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "flex-start",
                justifyContent: "flex-start",
                gap: "10px",
              }}
            >
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  padding: "4.813793182373047px",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "4.81px",
                }}
              >
                <div
                  style={{
                    position: "relative",
                    fontSize: "11px",
                    lineHeight: "150%",
                    fontFamily: "Vollkorn",
                    color: "#304050",
                    textAlign: "right",
                  }}
                >
                  Default Straddle
                </div>
                <FormControlLabel
                  style={{ position: "relative" }}
                  label=""
                  control={<Switch color="info" size="medium" />}
                />
              </div>
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  padding: "4.813793182373047px",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "4.81px",
                }}
              >
                <div
                  style={{
                    position: "relative",
                    fontSize: "11px",
                    lineHeight: "150%",
                    fontFamily: "Vollkorn",
                    color: "#304050",
                    textAlign: "right",
                  }}
                >
                  Default Double Straddle
                </div>
                <FormControlLabel
                  style={{ position: "relative" }}
                  label=""
                  control={<Switch color="primary" size="medium" />}
                />
              </div>
            </div>
          </div>
          <div
            style={{
              borderRadius: "4px",
              border: "1px solid #dcdee0",
              display: "flex",
              flexDirection: "row",
              padding: "6px 12px",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
            }}
            onClick={onButtonContainerClick}
          >
            <label
              style={{
                cursor: "pointer",
                position: "relative",
                fontSize: "16px",
                lineHeight: "150%",
                fontWeight: "700",
                fontFamily: "Vollkorn",
                color: "#0d1a26",
                textAlign: "left",
              }}
              htmlFor="NewSessionDoneButton"
            >
              Done
            </label>
          </div>
        </form>
        <div
          style={{
            alignSelf: "stretch",
            display: "flex",
            flexDirection: "column",
            padding: "30px 0px",
            alignItems: "flex-end",
            justifyContent: "flex-start",
          }}
        >
          <button
            style={{
              cursor: "pointer",
              border: "none",
              padding: "0",
              backgroundColor: "transparent",
              position: "relative",
              width: "60px",
              height: "30px",
              opacity: "0",
            }}
            data-animate-on-scroll
          >
            <div
              style={{
                position: "absolute",
                height: "100%",
                width: "100%",
                top: "0%",
                right: "0%",
                bottom: "0%",
                left: "0%",
                borderRadius: "5px 0px 0px 5px",
                backgroundColor: "#ececec",
              }}
            />
            <img
              style={{
                position: "absolute",
                height: "80%",
                width: "40%",
                top: "10%",
                right: "30%",
                bottom: "10%",
                left: "30%",
                maxWidth: "100%",
                overflow: "hidden",
                maxHeight: "100%",
              }}
              alt=""
              src="/connection--24--outline2.svg"
            />
          </button>
        </div>
      </div>
    </div>
  );
};

export default NewSessionPageMobile;
