import { useEffect } from "react";
import MainHeader from "../components/MainHeader";

const AllHandsPageSelectedHandMob = () => {
  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add("animate");
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  return (
    <div
      style={{
        position: "relative",
        backgroundColor: "#fff",
        width: "100%",
        height: "932px",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        justifyContent: "flex-start",
        textAlign: "center",
        fontSize: "19.37px",
        color: "#000",
        fontFamily: "Vollkorn",
      }}
    >
      <MainHeader dimensions="/onlylogo6.svg" />
      <div
        style={{
          alignSelf: "stretch",
          flex: "1",
          overflow: "hidden",
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          gap: "10px",
        }}
      >
        <div
          style={{
            alignSelf: "stretch",
            display: "flex",
            flexDirection: "column",
            padding: "75px 0px",
            alignItems: "flex-start",
            justifyContent: "flex-start",
          }}
        >
          <button
            style={{
              cursor: "pointer",
              border: "none",
              padding: "0",
              backgroundColor: "transparent",
              position: "relative",
              width: "40px",
              height: "20px",
              opacity: "0",
            }}
            data-animate-on-scroll
          >
            <div
              style={{
                position: "absolute",
                height: "100%",
                width: "100%",
                top: "0%",
                right: "0%",
                bottom: "0%",
                left: "0%",
                borderRadius: "0px 3.92px 3.92px 0px",
                backgroundColor: "#ececec",
              }}
            />
            <img
              style={{
                position: "absolute",
                height: "80%",
                width: "40%",
                top: "10%",
                right: "30%",
                bottom: "10%",
                left: "30%",
                maxWidth: "100%",
                overflow: "hidden",
                maxHeight: "100%",
              }}
              alt=""
              src="/connection--24--outline6.svg"
            />
          </button>
        </div>
        <div
          style={{
            alignSelf: "stretch",
            flex: "1",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "flex-end",
            position: "relative",
            gap: "200px",
          }}
        >
          <div
            style={{
              alignSelf: "stretch",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "flex-start",
              gap: "20px",
              zIndex: "0",
            }}
          >
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "flex-end",
                gap: "8.07px",
              }}
            >
              <b
                style={{
                  position: "relative",
                  lineHeight: "150%",
                  textAlign: "left",
                }}
              >
                Hand #2
              </b>
              <div
                style={{
                  width: "308.63px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "flex-start",
                  justifyContent: "flex-start",
                  gap: "3.44px",
                  fontSize: "13.75px",
                }}
              >
                <div
                  style={{
                    alignSelf: "stretch",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "flex-start",
                    justifyContent: "flex-start",
                  }}
                >
                  <div
                    style={{
                      alignSelf: "stretch",
                      backgroundColor: "#e9e9e9",
                      overflow: "hidden",
                      display: "flex",
                      flexDirection: "row",
                      padding: "6.87375545501709px 0px",
                      alignItems: "flex-start",
                      justifyContent: "flex-start",
                      gap: "68.74px",
                    }}
                  >
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      <p style={{ margin: "0" }}>&nbsp;</p>
                      <p style={{ margin: "0" }}>Board</p>
                      <p style={{ margin: "0" }}>Pot #1</p>
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      Blinds
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      <p style={{ margin: "0" }}>Preflop</p>
                      <p style={{ margin: "0" }}>&nbsp;</p>
                      <p style={{ margin: "0" }}>(175$)</p>
                    </div>
                  </div>
                  <img
                    style={{
                      alignSelf: "stretch",
                      position: "relative",
                      maxWidth: "100%",
                      overflow: "hidden",
                      height: "3.67px",
                      flexShrink: "0",
                    }}
                    alt=""
                    src="/line-2.svg"
                  />
                </div>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    padding: "0px 0px 0px 103.10633087158203px",
                    alignItems: "flex-start",
                    justifyContent: "flex-start",
                    gap: "27.5px",
                    textAlign: "left",
                    fontSize: "11px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "flex-start",
                      justifyContent: "flex-start",
                      gap: "13.75px",
                    }}
                  >
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      SB posts 25$
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      BB posts 50$
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      UTG straddles 100$
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      BU dealt cards 6♠ T♥
                    </div>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "flex-start",
                      justifyContent: "flex-start",
                      gap: "13.75px",
                    }}
                  >
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      HJ folds
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      BU raises 250$
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      SB folds
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      BB calls 200$
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      UTG calls 150$
                    </div>
                  </div>
                </div>
              </div>
              <div
                style={{
                  width: "309.04px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "flex-start",
                  justifyContent: "flex-start",
                  gap: "3.73px",
                  fontSize: "14.93px",
                }}
              >
                <div
                  style={{
                    alignSelf: "stretch",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "flex-start",
                    justifyContent: "flex-start",
                  }}
                >
                  <div
                    style={{
                      alignSelf: "stretch",
                      backgroundColor: "#e9e9e9",
                      overflow: "hidden",
                      display: "flex",
                      flexDirection: "row",
                      padding: "7.4646148681640625px 0px",
                      alignItems: "flex-start",
                      justifyContent: "flex-start",
                      gap: "74.65px",
                    }}
                  >
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      <p style={{ margin: "0" }}>&nbsp;</p>
                      <p style={{ margin: "0" }}>Board</p>
                      <p style={{ margin: "0" }}>Pot #1</p>
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      <p style={{ margin: "0" }}>Flop</p>
                      <p style={{ margin: "0" }}>2♣ 5♥ 7♣</p>
                      <p style={{ margin: "0" }}>(775$)</p>
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      <p style={{ margin: "0" }}>Turn</p>
                      <p style={{ margin: "0" }}>8♥</p>
                      <p style={{ margin: "0" }}>(1375$)</p>
                    </div>
                  </div>
                  <img
                    style={{
                      alignSelf: "stretch",
                      position: "relative",
                      maxWidth: "100%",
                      overflow: "hidden",
                      height: "3.98px",
                      flexShrink: "0",
                    }}
                    alt=""
                    src="/line-21.svg"
                  />
                </div>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    padding: "0px 0px 0px 130.63075256347656px",
                    alignItems: "flex-start",
                    justifyContent: "flex-start",
                    gap: "29.86px",
                    textAlign: "left",
                    fontSize: "11.94px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "flex-start",
                      justifyContent: "flex-start",
                      gap: "14.93px",
                    }}
                  >
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      BB checks
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      UTG checks
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      BU bets 300$
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      BB calls 300$
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      UTG folds
                    </div>
                  </div>
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "flex-start",
                      justifyContent: "flex-start",
                      gap: "14.93px",
                    }}
                  >
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      BU bets 1000$
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      BB calls 1000$
                    </div>
                  </div>
                </div>
              </div>
              <div
                style={{
                  width: "309.44px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "flex-start",
                  justifyContent: "flex-start",
                  gap: "4.04px",
                  fontSize: "16.16px",
                }}
              >
                <div
                  style={{
                    alignSelf: "stretch",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "flex-start",
                    justifyContent: "flex-start",
                  }}
                >
                  <div
                    style={{
                      alignSelf: "stretch",
                      backgroundColor: "#e9e9e9",
                      overflow: "hidden",
                      display: "flex",
                      flexDirection: "row",
                      padding: "8.07933521270752px 0px",
                      alignItems: "flex-start",
                      justifyContent: "flex-start",
                      gap: "80.79px",
                    }}
                  >
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      <p style={{ margin: "0" }}>&nbsp;</p>
                      <p style={{ margin: "0" }}>Board</p>
                      <p style={{ margin: "0" }}>Pot #1</p>
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      <p style={{ margin: "0" }}>River</p>
                      <p style={{ margin: "0" }}>9♦</p>
                      <p style={{ margin: "0" }}>(3375$)</p>
                    </div>
                  </div>
                  <img
                    style={{
                      alignSelf: "stretch",
                      position: "relative",
                      maxWidth: "100%",
                      overflow: "hidden",
                      height: "4.31px",
                      flexShrink: "0",
                    }}
                    alt=""
                    src="/line-22.svg"
                  />
                </div>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    padding: "0px 0px 0px 121.19001770019531px",
                    alignItems: "flex-start",
                    justifyContent: "flex-start",
                    textAlign: "left",
                    fontSize: "12.93px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "flex-start",
                      justifyContent: "flex-start",
                      gap: "16.16px",
                    }}
                  >
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      BU all-in 2450
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      BB all-in 1950$
                    </div>
                    <div
                      style={{ position: "relative", lineHeight: "150%" }}
                    >{`BU shows 6♠ T♥ `}</div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      BB shows 7♥ 9♥
                    </div>
                    <div style={{ position: "relative", lineHeight: "150%" }}>
                      BU wins
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div
              style={{
                alignSelf: "stretch",
                height: "42px",
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                textAlign: "left",
                fontSize: "12.07px",
                color: "#808080",
              }}
            >
              <div
                style={{
                  alignSelf: "stretch",
                  flex: "1",
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <div
                  style={{
                    alignSelf: "stretch",
                    flex: "1",
                    borderRadius: "3.02px",
                    border: "0.8px solid #aeb3b7",
                    display: "flex",
                    flexDirection: "row",
                    padding: "6.03636360168457px 12.07272720336914px",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "7.55px",
                  }}
                >
                  <div
                    style={{
                      flex: "1",
                      position: "relative",
                      lineHeight: "150%",
                    }}
                  >
                    Tell me your hand
                  </div>
                  <img
                    style={{
                      position: "relative",
                      width: "18.11px",
                      height: "18.11px",
                      overflow: "hidden",
                      flexShrink: "0",
                    }}
                    alt=""
                    src="/paper-plane--24--outline2.svg"
                  />
                </div>
              </div>
            </div>
          </div>
          <div
            style={{
              margin: "0",
              position: "absolute",
              top: "25px",
              left: "12px",
              overflow: "hidden",
              display: "flex",
              flexDirection: "row",
              padding: "1.6823214292526245px 0px",
              alignItems: "center",
              justifyContent: "flex-start",
              gap: "8.41px",
              zIndex: "1",
              textAlign: "left",
              fontSize: "11.78px",
            }}
          >
            <img
              style={{
                position: "relative",
                width: "16.82px",
                height: "13.46px",
              }}
              alt=""
              src="/vector4.svg"
            />
            <div
              style={{
                position: "relative",
                lineHeight: "16.82px",
                fontWeight: "500",
              }}
            >
              Edit Session
            </div>
          </div>
        </div>
        <div
          style={{
            alignSelf: "stretch",
            display: "flex",
            flexDirection: "column",
            padding: "75px 0px",
            alignItems: "flex-end",
            justifyContent: "flex-start",
          }}
        >
          <button
            style={{
              cursor: "pointer",
              border: "none",
              padding: "0",
              backgroundColor: "transparent",
              position: "relative",
              width: "40px",
              height: "20px",
              opacity: "0",
            }}
            data-animate-on-scroll
          >
            <div
              style={{
                position: "absolute",
                height: "100%",
                width: "100%",
                top: "0%",
                right: "0%",
                bottom: "0%",
                left: "0%",
                borderRadius: "5px 0px 0px 5px",
                backgroundColor: "#ececec",
              }}
            />
            <img
              style={{
                position: "absolute",
                height: "80%",
                width: "40%",
                top: "10%",
                right: "30%",
                bottom: "10%",
                left: "30%",
                maxWidth: "100%",
                overflow: "hidden",
                maxHeight: "100%",
              }}
              alt=""
              src="/connection--24--outline8.svg"
            />
          </button>
        </div>
      </div>
    </div>
  );
};

export default AllHandsPageSelectedHandMob;
